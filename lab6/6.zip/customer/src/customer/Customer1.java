/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;

import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

/**
 *
 * @author student
 */
public class Customer1 {

    /**
     * @param args the command line arguments
     */
    
    private int id;
    private String surname;
    private String name;
    private String middleName;
    private String address;
    private int phoneNumber;
    private int ccNumber; //credit card number
    private int baNumber; //bank account number
    
    public Customer1(){
        this.id=0;
        this.surname="";
        this.name="";
        this.middleName="";
        this.address="";
        this.phoneNumber=0;
        this.ccNumber=0;
        this.baNumber=0;
    }
    
    public Customer1(int id, String surname, String name, String middleName, String address, int phoneNumber, int ccNumber, int baNumber){
        this.id=id;
        this.surname=surname;
        this.name=name;
        this.middleName=middleName;
        this.address=address;
        this.phoneNumber=phoneNumber;
        this.ccNumber=ccNumber;
        this.baNumber=baNumber;
    }


    public int getCcNumber() {
        return ccNumber;
    }

    public String getSurname() {
        return surname;
    }

    
    public String toString(){
        return "Покупатель - - - "+
               "id: "+id+
                ", Фамилия: "+surname+
                ", Имя: "+ name+
                ", Отчество: "+middleName+
                ", Адрес: "+address+
                ", Номер телефона: "+phoneNumber+
                ", Номер кредитной карты: "+ccNumber+
                ", Номер банковского счета: "+baNumber+ "\n";
    }
    
                
    public static void main(String[] args) {
        
    }    
}
    
    
class Customer1Data{
    static ArrayList<Customer1> customer(){
        ArrayList<Customer1> cust = new ArrayList<Customer1>();
        
        cust.add(new Customer1(1,"Иванов", "Иван", "Иванович", "Рябинина 8", 12456, 1, 125467));
        cust.add(new Customer1(2,"Николаев", "Николай", "Николаевич", "Рябинина 9", 78451, 4, 489815));
        cust.add(new Customer1(3,"Васильков", "Василий", "Васильевич", "Рябинина 10", 357846, 8, 965471));
        cust.add(new Customer1(4,"Абрамов", "Константин", "Васильевич", "Рябинина 11", 54789, 2, 6984741));
        cust.add(new Customer1(5,"Рябинин", "Константин", "Иванович", "Рябинина 7", 258746, 3, 584714));
        
        return cust;
    }
        
    static void addNewCustomer(ArrayList<Customer1>  cust, int n, String surname, String name, String middleName, String address, int phoneNumber, int ccNumber, int baNumber){
        cust.add(new Customer1(n, surname, name, middleName, address, phoneNumber, ccNumber, baNumber));
    }
    
}
